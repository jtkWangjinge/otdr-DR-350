/*******************************************************************************
* Copyright(c)2020，捷太科仪器(苏州)有限公司上海研发部
*
* All rights reserved
*
* 文件名称：  app_frmupdate.h
* 摘    要：  声明系统升级相关函数
*
*
* 当前版本：  v1.0.0
* 作    者：  wjg
* 完成日期：  2020-10-21
*
*******************************************************************************/
#include "app_frmupdate.h"


/*******************************************************************************
**					为实现应用层frmupdate而需要引用的其他头文件 			  **
*******************************************************************************/
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>

#include <dirent.h>
#include <stdlib.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/vfs.h>  

/*******************************************************************************
**									宏定义 				 					  **
*******************************************************************************/
#define BOOTMTD			0
#define LOGOMTD			1
#define RECOVERYMTD		2
#define FPGA1MTD		3
#define FPGA2MTD		4
#define KERNELMTD		5
#define ROOTFSMTD		6
#define CACHEMTD		7
#define RESERVED1MTD	8
#define RESERVED2MTD	9
#define USERFSMTD		10


/**********************************************************************************
**								变量定义				 						 **
***********************************************************************************/
static unsigned char __g_ucUserFsLowVersionFlg = 0;		// 待升级应用程序低于当前版本标记，1有效
static VERSION	 __g_CurVersion;						// 当前系统的版本信息
static VERSION	 __g_NewVersion;						// 即将升级的版本信息

static int __g_msgid = -1;
static struct msg_st __g_Message;


/***
  * 功能：
		输出当前系统中文件与升级文件版本信息
  * 参数：
		1、CurVersion :	当前文件结构体
		2、UpdateVersion : 待升级文件结构体
  * 返回：
		无
  * 备注：
***/
void PrintFilesVersion(VERSION *CurVersion, VERSION *UpdateVersion)
{
    printf("         <Current files version>---<Updata files version>\n");
    printf("BootStrap  :       %s                       %s\n", CurVersion->BootStrap, 	UpdateVersion->BootStrap);
    printf("Logo       :       %s                       %s\n", CurVersion->Logo, 		UpdateVersion->Logo);
	printf("Recovery   :       %s                       %s\n", CurVersion->Recovery, 	UpdateVersion->Recovery);
	printf("Fpga       :       %s                       %s\n", CurVersion->Fpga, 		UpdateVersion->Fpga);
    printf("Kernel     :       %s                       %s\n", CurVersion->Kernel, 		UpdateVersion->Kernel);
    printf("Rootfs     :       %s                       %s\n", CurVersion->Rootfs, 		UpdateVersion->Rootfs);
    printf("Userfs     :       %s                       %s\n", CurVersion->Userfs, 		UpdateVersion->Userfs);
    printf("Reserved1  :       %s                       %s\n", CurVersion->Reserved1, 	UpdateVersion->Reserved1);
    printf("Reserved2  :       %s                       %s\n", CurVersion->Reserved2, 	UpdateVersion->Reserved2);
}


/***
  * 功能：
        写入BootStrap.img
  * 参数：
        无
  * 返回：
        成功返回零，失败返回非零值
  * 备注：
***/
int WriteBootStrap(void)
{
	int iErr = 0;
	int iReturn = 0;
	int iRetryTime = 0;
	int iOriginaSize = 0;
	char cBuffOrigina[1024];
	char cBuffRead[1024];
	char cCmdBuff[512];

	do
	{
		int iOriginalFd;
		int iReadFd;

		if(iErr == 0)
		{
			sprintf(cCmdBuff, "flash_eraseall /dev/mtd%d", BOOTMTD);
			iReturn = mysystem(cCmdBuff);
			if(iReturn != 0)
			{
				iErr = -1;
			}
		}

		if(iErr == 0)
		{
			sprintf(cCmdBuff, "nandwrite -p /dev/mtd%d /update/BootStrap.img", BOOTMTD);
			iReturn = mysystem(cCmdBuff);
			if(iReturn != 0)
			{
				iErr = -2;
			}
		}

		if(iErr == 0)
		{
			/* 读取写下去的文件 */
			sprintf(cCmdBuff, "nanddump --bb=skipbad --omitoob -f /update/ReadBootStrap.img /dev/mtd%d", BOOTMTD);
			iReturn = mysystem(cCmdBuff);
			if(iReturn != 0)
			{
				iErr = -3;
			}
		}

		if(iErr == 0)
		{
			iOriginalFd = open("/update/BootStrap.img", O_RDONLY);
			iReadFd = open("/update/ReadBootStrap.img", O_RDONLY);
			LOG(LOG_ERROR, "iOriginalFd = %d\n", iOriginalFd);
			LOG(LOG_ERROR, "iReadFd = %d\n", iReadFd);
			if((iOriginalFd==-1) || (iReadFd==-1))
			{
				iErr = -4;
			}
		}

		if(iErr == 0)
		{
			/* 比较源文件和读取的文件是否相同 */
			do
			{
				iOriginaSize = read(iOriginalFd, cBuffOrigina, sizeof(cBuffOrigina));
				read(iReadFd, cBuffRead, iOriginaSize);
				iReturn = memcmp(cBuffOrigina, cBuffRead, iOriginaSize);
			}while((iReturn==0) && (iOriginaSize==1024));
			iRetryTime++;
			close(iOriginalFd);
			close(iReadFd);
		}

	}while((iReturn!=0) && (iRetryTime<10));
	LOG(LOG_ERROR, "iRetryTime = %d \n", iRetryTime);

	mysystem("rm -rf /update/BootStrap.img");
	mysystem("rm -rf /update/ReadBootStrap.img");

	if( (iReturn!=0) || (iRetryTime>=10) )
	{
		iErr = -5;
	}

	return iErr;
}


/***
  * 功能：
        写入Logo.img
  * 参数：
        无
  * 返回：
        成功返回零，失败返回非零值
  * 备注：
***/
int WriteLogo(void)
{
	int iErr = 0;
	int iReturn = 0;
	int iRetryTime = 0;
	int iOriginaSize = 0;
	char cBuffOrigina[1024];
	char cBuffRead[1024];
	char cCmdBuff[512];

	do
	{
		int iOriginalFd;
		int iReadFd;

		if(iErr == 0)
		{
			sprintf(cCmdBuff, "flash_eraseall /dev/mtd%d", LOGOMTD);
			iReturn = mysystem(cCmdBuff);
			if(iReturn != 0)
			{
				iErr = -1;
			}
		}

		if(iErr == 0)
		{
			sprintf(cCmdBuff, "nandwrite -p /dev/mtd%d /update/Logo.img", LOGOMTD);
			iReturn = mysystem(cCmdBuff);
			if(iReturn != 0)
			{
				iErr = -2;
			}
		}

		if(iErr == 0)
		{
			/* 读取写下去的文件 */
			sprintf(cCmdBuff, "nanddump --bb=skipbad --omitoob -f /update/ReadLogo.img /dev/mtd%d", LOGOMTD);
			iReturn = mysystem(cCmdBuff);
			if(iReturn != 0)
			{
				iErr = -3;
			}
		}

		if(iErr == 0)
		{
			iOriginalFd = open("/update/Logo.img", O_RDONLY);
			iReadFd = open("/update/ReadLogo.img", O_RDONLY);
			LOG(LOG_ERROR, "iOriginalFd = %d\n", iOriginalFd);
			LOG(LOG_ERROR, "iReadFd = %d\n", iReadFd);
			/* 若文件打开失败，则认为烧写成功 */
			if((iOriginalFd==-1) || (iReadFd==-1))
			{
				iErr = -4;
			}
		}

		if(iErr == 0)
		{
			/* 比较源文件和读取的文件是否相同 */
			do
			{
				iOriginaSize = read(iOriginalFd, cBuffOrigina, sizeof(cBuffOrigina));
				read(iReadFd, cBuffRead, iOriginaSize);
				iReturn = memcmp(cBuffOrigina, cBuffRead, iOriginaSize);
			}while((iReturn==0) && (iOriginaSize==1024));
			iRetryTime++;
			close(iOriginalFd);
			close(iReadFd);
		}

	}while((iReturn!=0) && (iRetryTime<10));
	LOG(LOG_ERROR, "iReturn = %d\n", iReturn);
	LOG(LOG_ERROR, "iRetryTime = %d \n", iRetryTime);

	mysystem("rm -rf /update/Logo.img");
	mysystem("rm -rf /update/ReadLogo.img");

	if( (iReturn!=0) || (iRetryTime>=10) )
	{
		iErr = -5;
	}

	return iErr;
}


/***
  * 功能：
        写入Recovery.img
  * 参数：
        无
  * 返回：
        成功返回零，失败返回非零值
  * 备注：
***/
int WriteRecovery(void)
{
	int iErr = 0;
	int iReturn = 0;
	int iRetryTime = 0;
	int iOriginaSize = 0;
	char cBuffOrigina[1024];
	char cBuffRead[1024];
	char cCmdBuff[512];

	do
	{
		int iOriginalFd;
		int iReadFd;

		if(iErr == 0)
		{
			sprintf(cCmdBuff, "flash_eraseall /dev/mtd%d", RECOVERYMTD);
			iReturn = mysystem(cCmdBuff);
			if(iReturn != 0)
			{
				iErr = -1;
			}
		}

		if(iErr == 0)
		{
			sprintf(cCmdBuff, "nandwrite -p /dev/mtd%d /update/Recovery.img", RECOVERYMTD);
			iReturn = mysystem(cCmdBuff);
			if(iReturn != 0)
			{
				iErr = -2;
			}
		}

		if(iErr == 0)
		{
			/* 读取写下去的文件 */
			sprintf(cCmdBuff, "nanddump --bb=skipbad --omitoob -f /update/ReadRecovery.img /dev/mtd%d", RECOVERYMTD);
			iReturn = mysystem(cCmdBuff);
			if(iReturn != 0)
			{
				iErr = -3;
			}
		}

		if(iErr == 0)
		{
			iOriginalFd = open("/update/Recovery.img", O_RDONLY);
			iReadFd = open("/update/ReadRecovery.img", O_RDONLY);
			LOG(LOG_ERROR, "iOriginalFd = %d\n", iOriginalFd);
			LOG(LOG_ERROR, "iReadFd = %d\n", iReadFd);
			if((iOriginalFd==-1) || (iReadFd==-1))
			{
				iErr = -4;
			}
		}

		if(iErr == 0)
		{
			/* 比较源文件和读取的文件是否相同 */
			do
			{
				iOriginaSize = read(iOriginalFd, cBuffOrigina, sizeof(cBuffOrigina));
				read(iReadFd, cBuffRead, iOriginaSize);
				iReturn = memcmp(cBuffOrigina, cBuffRead, iOriginaSize);
			}while((iReturn==0) && (iOriginaSize==1024));
			iRetryTime++;
			close(iOriginalFd);
			close(iReadFd);
		}

	}while((iReturn!=0) && (iRetryTime<10));
	LOG(LOG_ERROR, "iReturn = %d\n", iReturn);
	LOG(LOG_ERROR, "iRetryTime = %d \n", iRetryTime);

	mysystem("rm -rf /update/Recovery.img");
	mysystem("rm -rf /update/ReadRecovery.img");

	if( (iReturn!=0) || (iRetryTime>=10) )
	{
		iErr = -5;
	}

	return iErr;
}


/***
  * 功能：
        写入FPGA
  * 参数：
        无
  * 返回：
        成功返回零，失败返回非零值
  * 备注：
***/
int WriteFpga(void)
{
	int iReturn = 0;
	int iErr = 0;
	int iRetryTime = 0;
	int iOriginalFd;
	int iReadFd;
	int iOriginaSize = 0;
	int iReadSize = 0;
	char cBuffOrigina[1024];
	char cBuffRead[1024];
	char cCmdBuff[512];
	//char PB8[2];
	//char PB9[2];
	//char PB27[2];
	FILE *Fp = NULL;

	do
	{
		if(iErr == 0)
		{
			sprintf(cCmdBuff, "flash_eraseall /dev/mtd%d", FPGA1MTD);
			iReturn = mysystem(cCmdBuff);
			if(iReturn != 0)
			{
				iErr = -1;
				break;
			}
		}

		if(iErr == 0)
		{
			sprintf(cCmdBuff, "nandwrite -p /dev/mtd%d /update/f216fpga_XIN_LX16.bin", FPGA1MTD);
			iReturn = mysystem(cCmdBuff);
			if(iReturn != 0)
			{
				iErr = -2;
				break;
			}
		}

		if(iErr == 0)
		{
			/* 读取写下去的文件 */
			sprintf(cCmdBuff, "nanddump --bb=skipbad --omitoob -f /update/Readf216fpga_XIN_LX16.bin /dev/mtd%d", FPGA1MTD);
			iReturn = mysystem(cCmdBuff);
			if(iReturn != 0)
			{
				iErr = -3;
				break;
			}
		}

		if(iErr == 0)
		{
			iOriginalFd = open("/update/f216fpga_XIN_LX16.bin", O_RDONLY);
			iReadFd = open("/update/Readf216fpga_XIN_LX16.bin", O_RDONLY);
			LOG(LOG_ERROR, "iOriginalFd = %d\n", iOriginalFd);
			LOG(LOG_ERROR, "iReadFd = %d\n", iReadFd);
			if((iOriginalFd==-1) || (iReadFd==-1))
			{
				iErr = -4;
				break;
			}
		}


		if(iErr == 0)
		{
			/* 比较源文件和读取的文件是否相同 */
			do
			{
				iOriginaSize = read(iOriginalFd, cBuffOrigina, sizeof(cBuffOrigina));
				read(iReadFd, cBuffRead, iOriginaSize);
				iReturn = memcmp(cBuffOrigina, cBuffRead, iOriginaSize);
			}while((iReturn==0) && (iOriginaSize==1024));
			iRetryTime++;
			close(iOriginalFd);
			close(iReadFd);
		}

	}while((iReturn!=0) && (iRetryTime<10));
	LOG(LOG_ERROR, "iReturn = %d \n", iReturn);
	LOG(LOG_ERROR, "iRetryTime = %d \n", iRetryTime);

	mysystem("rm -rf /update/f216fpga_XIN_LX16.bin");
	mysystem("rm -rf /update/Readf216fpga_XIN_LX16.bin");

	if( (iReturn!=0) || (iRetryTime>=10) )
	{
		iErr = -5;
	}
        
	return iErr;
}


/***
  * 功能：
        写入Kernel.img
  * 参数：
        无
  * 返回：
        成功返回零，失败返回非零值
  * 备注：
***/
int WriteKernel(void)
{
	int iErr = 0;
	int iReturn = 0;
	int iRetryTime = 0;
	int iOriginaSize = 0;
	char cBuffOrigina[1024];
	char cBuffRead[1024];
	char cCmdBuff[512];

	do
	{
		int iOriginalFd;
		int iReadFd;

		if(iErr == 0)
		{
			sprintf(cCmdBuff, "flash_eraseall /dev/mtd%d", KERNELMTD);
			iReturn = mysystem(cCmdBuff);
			if(iReturn != 0)
			{
				iErr = -1;
			}
		}

		if(iErr == 0)
		{
			sprintf(cCmdBuff, "nandwrite -p /dev/mtd%d /update/Kernel.img", KERNELMTD);
			iReturn = mysystem(cCmdBuff);
			if(iReturn != 0)
			{
				iErr = -2;
			}
		}

		if(iErr == 0)
		{
			/* 读取写下去的文件 */
			sprintf(cCmdBuff, "nanddump --bb=skipbad --omitoob -f /update/ReadKernel.img /dev/mtd%d", KERNELMTD);
			iReturn = mysystem(cCmdBuff);
			if(iReturn != 0)
			{
				iErr = -3;
			}
		}

		if(iErr == 0)
		{
			iOriginalFd = open("/update/Kernel.img", O_RDONLY);
			iReadFd = open("/update/ReadKernel.img", O_RDONLY);
			/* 若文件打开失败，则认为烧写成功 */
			if((iOriginalFd==-1) || (iReadFd==-1))
			{
				iErr = -4;
			}
		}

		if(iErr == 0)
		{
			/* 比较源文件和读取的文件是否相同 */
			do
			{
				iOriginaSize = read(iOriginalFd, cBuffOrigina, sizeof(cBuffOrigina));
				read(iReadFd, cBuffRead, iOriginaSize);
				iReturn = memcmp(cBuffOrigina, cBuffRead, iOriginaSize);
			}while((iReturn==0) && (iOriginaSize==1024));
			iRetryTime++;
			close(iOriginalFd);
			close(iReadFd);
		}

	}while((iReturn!=0) && (iRetryTime<10));
	LOG(LOG_ERROR, "iReturn = %d\n", iReturn);
	LOG(LOG_ERROR, "iRetryTime = %d \n", iRetryTime);

	mysystem("rm -rf /update/Kernel.img");
	mysystem("rm -rf /update/ReadKernel.img");

	if( (iReturn!=0) || (iRetryTime>=10) )
	{
		iErr = -5;
	}

	return iErr;
}


/***
  * 功能：
        写入Rootfs.img
  * 参数：
        无
  * 返回：
        成功返回零，失败返回非零值
  * 备注：
***/
int WriteRootfs(void)
{
	int iErr = 0;
	int iReturn = 0;
	int iRetryTime = 0;

	do
	{
	    mysystem("rm /lib/*2.5* -rf > dev/null");
	    mysystem("rm /bin/strace -rf > dev/null");
		iReturn = mysystem("tar -xzvf /update/Rootfs.img -C /rootfs");
		iRetryTime++;
	}while((iReturn!=0) && (iRetryTime<10));

	LOG(LOG_ERROR, "iReturn = %d\n", iReturn);
	LOG(LOG_ERROR, "iRetryTime = %d \n", iRetryTime);

	mysystem("rm -rf /update/Rootfs.img");

	if( (iReturn!=0) || (iRetryTime>=10) )
	{
		iErr = -1;
	}

	return iReturn;
}


/***
  * 功能：
        写入Userfs.img
  * 参数：
        无
  * 返回：
        成功返回零，失败返回非零值
  * 备注：
***/
int WriteUserfs(void)
{
	int iErr = 0;
	int iReturn = 0;
	int iRetryTime = 0;

	do
	{
		iReturn = mysystem("tar -xzvf /update/Userfs.img -C /userfs");
		iRetryTime++;
	}while((iReturn!=0) && (iRetryTime<10));

	LOG(LOG_ERROR, "iReturn = %d\n", iReturn);
	LOG(LOG_ERROR, "iRetryTime = %d \n", iRetryTime);

	mysystem("rm -rf /update/Userfs.img");

	if( (iReturn!=0) || (iRetryTime>=10) )
	{
		iErr = -1;
	}

	return iErr;
}


/***
  * 功能：
        从指定路径中读取版本信息
  * 参数：
        1、const char *pFilePath	:	存放版本信息的路径
        2、VERSION *pPar			:	存贮版本信息的变量
  * 返回：
        成功返回零，失败返回非零值
  * 备注：
***/
int ReadUpdateVersion(const char *pFilePath, VERSION *pPar)
{
	int iErr = 0;
	int ifd;

	if(iErr == 0)
	{
		if(!pFilePath || !pPar)
		{
			iErr = -1;
		}
	}

	if(iErr == 0)
	{
		ifd = open(pFilePath, O_RDONLY);
	    if (ifd == -1)
	    {
	        printf("Failed to open %s\n", pFilePath);
	        iErr = -2;
	    }
	}

	if(iErr == 0)
	{
		read(ifd, pPar, sizeof(VERSION));
		close(ifd);
	}

	return iErr;
}


/***
  * 功能：
        保存升级版本信息
  * 参数：
        1、const char *pFilePath	:	存放版本信息的路径
        2、VERSION *pPar			:	存贮版本信息的变量
  * 返回：
        成功返回零，失败返回非零值
  * 备注：
***/
static int SaveUpdateVersion(VERSION *pUpdateVersion)
{
	int iErr = 0;

	int iFd;

	if(iErr == 0)
	{
		if(NULL == pUpdateVersion)
		{
			iErr = -1;
		}
	}

	if(iErr == 0)
	{
		if( (iFd=open("/app/version.bin", O_WRONLY | O_TRUNC)) == -1 )
		{
			iErr = -2;
		}
		else
		{
			write(iFd, pUpdateVersion, sizeof(VERSION));
			close(iFd);
		}
	}

	return iErr;
}


/***
  * 功能：
		解压升级包文件，创建需要升级的各个文件
  * 参数：
		无
  * 返回：
		成功返回零，失败返回非零值
		其中-4代表升级机器不匹配
  * 备注：
***/
int CreateUpdateFile(const char *cUpdateFileName)
{
	int iErr = 0;
	int iReturn = 0;
	int iRetryTime = 0;
	char cCmdBuff[512];

	if(iErr == 0)
	{
		if(NULL == cUpdateFileName)
		{
			iErr = -1;
		}
	}

	/* 解压升级包 */
	if(iErr == 0)
	{
		sprintf(cCmdBuff, "tar -xzvf %s -C /update", cUpdateFileName);
		do
		{
			iReturn = mysystem(cCmdBuff);
			iRetryTime++;
		}while((iReturn!=0) && (iRetryTime<10));

		LOG(LOG_ERROR, "iRetryTime = %d \n", iRetryTime);

		if( (iReturn!=0) || (iRetryTime>=10) )
		{
			iErr = -1;
		}
	}

	#ifndef FIRST_WRITE
	if(iErr == 0)
	{
		/* 读取升级包内的版本信息 */
		memset(&__g_NewVersion, 0, sizeof(VERSION));
		iReturn = ReadUpdateVersion("/update/version.bin", &__g_NewVersion);
		if(iReturn < 0)
		{
			iErr = -2;
		}
	}

	if(iErr == 0)
	{
		/* 读取当前系统中存贮的版本信息 */
		memset(&__g_CurVersion, 0, sizeof(VERSION));
		iReturn = ReadUpdateVersion("/app/version.bin", &__g_CurVersion);
		if(iReturn < 0)
		{
			iErr = -3;
		}
	}

	if(iErr == 0)
	{
		/* 输出文件版本信息 */
		PrintFilesVersion(&__g_CurVersion, &__g_NewVersion);

		/* 禁止机器型号版本串改 */
	    if (strcmp(MACHINTYPE, __g_NewVersion.MachineType))
	    {
			iErr = -4;
	    }
	}

	if(iErr == 0)
	{
		/* 判断BootStrap.img的版本 */
	    iReturn = strcmp(__g_NewVersion.BootStrap, __g_CurVersion.BootStrap);
		/* 只有待升级文件版本不与当前版本相同才升级 */
	    if (iReturn == 0)
	    {
			mysystem("rm -rf /update/BootStrap.img");
	    }

		/* 判断Logo.img的版本 */
	    iReturn = strcmp(__g_NewVersion.Logo, __g_CurVersion.Logo);
		/* 只有待升级文件版本不与当前版本相同才升级 */
	    if (iReturn == 0)
	    {
			mysystem("rm -rf /update/Logo.img");
	    }

		/* 判断Recovery.img的版本 */
	    iReturn = strcmp(__g_NewVersion.Recovery, __g_CurVersion.Recovery);
		/* 只有待升级文件版本不与当前版本相同才升级 */
	    if (iReturn == 0)
	    {
			mysystem("rm -rf /update/Recovery.img");
	    }

		/* 判断Fpga.img的版本 */
	    iReturn = strcmp(__g_NewVersion.Fpga, __g_CurVersion.Fpga);
		/* 只有待升级文件版本不与当前版本相同才升级 */
	    if (iReturn == 0)
	    {
	    	mysystem("rm -rf /update/f216fpga_XIN_LX16.bin");
	    }

		/* 判断Kernel.img的版本 */
	    iReturn = strcmp(__g_NewVersion.Kernel, __g_CurVersion.Kernel);
		/* 只有待升级文件版本不与当前版本相同才升级 */
	    if (iReturn == 0)
	    {
			mysystem("rm -rf /update/Kernel.img");
	    }

		/* 判断Rootfs.img的版本 */
	    iReturn = strcmp(__g_NewVersion.Rootfs, __g_CurVersion.Rootfs);
		/* 只有待升级文件版本不与当前版本相同才升级 */
	    if (iReturn == 0)
	    {
			mysystem("rm -rf /update/Rootfs.img");
	    }

		/* 判断Userfs.img的版本 */
	    iReturn = strcmp(__g_NewVersion.Userfs, __g_CurVersion.Userfs);
		/* 只有待升级文件版本不与当前版本相同才升级 */
	    if (1)
	    {
	    	if(iReturn < 0)
    		{
    			__g_ucUserFsLowVersionFlg = 1;
               // iErr = -6;
    		}
			else
			{
				__g_ucUserFsLowVersionFlg = 0;
			}
	    }
		else
		{
			mysystem("rm -rf /update/Userfs.img");
		}
	}
	#endif

    return iErr;
}


/***
  * 功能：
		返回待升级应用程序低于当前版本标记
  * 参数：
		无
  * 返回：
		返回待升级应用程序低于当前版本标记
  * 备注：
***/
unsigned char GetUserFsLowVersionFlg(void)
{
	return __g_ucUserFsLowVersionFlg;
}


/***
  * 功能：
        实现对popen函数的二次封装
  * 参数：
        1.char *pCmd:	需要执行的命令行
  * 返回：
        成功返回零，失败返回非零值
  * 备注：
***/
int mysystem(char *pCmd)
{
	int iReturn = 0;
	int iStatus = 0;
	FILE *Fp = NULL;
	char cResultBuff[1024];

	if(NULL == pCmd)
	{
		printf("pCmd is NULL\n");
		return -1;
	}

	/* 执行命令 */
	Fp = popen(pCmd, "r");
	/* 命令执行失败 */
	if(NULL == Fp)
	{
		//printf("popen error: %s\n", strerror(errno));
		return -1;
	}

	printf("%s\n", pCmd);

	/* 打印命令执行结果 */
    while(fgets(cResultBuff, sizeof(cResultBuff), Fp) != NULL)
    {
        printf("%s", cResultBuff);
    }

    /*等待命令执行完毕并关闭管道及文件指针*/
    iStatus = pclose(Fp);
    if(-1 == iStatus)
    {
        printf("pclose fail!\n");
        return -2;
    }
    else
    {
       //printf("iStatus = %d\n", iStatus);
	   printf("WEXITSTATUS(iStatus) = %d\n", WEXITSTATUS(iStatus));
	   iReturn = WEXITSTATUS(iStatus);
    }

	return iReturn;
}


/***
  * 功能：
		初始化消息队列
  * 参数：
		无
  * 返回：
		成功返回零，失败返回非零值
  * 备注：
***/
int InitMsgQueue(void)
{
	int iErr = 0;

	//建立消息队列
	__g_msgid = msgget((key_t)1235, 0666 | IPC_CREAT);
	if(__g_msgid == -1)
	{
		iErr = -1;
	}

	return iErr;
}


/***
  * 功能：
		向消息队列发送消息
  * 参数：
		1、int iCmdType		:	命令码
		2、int iParameter	:	附加参数
  * 返回：
		成功返回零，失败返回非零值
  * 备注：
***/
int MsgSend(int iCmdType, int iParameter)
{
	int iErr = 0;

	struct msg Msg;

	Msg.iCmdType = iCmdType;
	Msg.iParameter = iParameter;
	memcpy(__g_Message.message, &Msg, sizeof(Msg));
	__g_Message.msg_type = FROM_SERVER;

	printf("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ServerSend iCmdType = %d, iParameter = %d\n", Msg.iCmdType, Msg.iParameter);


	if(msgsnd(__g_msgid, (void*)&__g_Message, MESSAGE_NUM, 0) == -1)
	{
		iErr = -1;
	}

	return iErr;
}


/***
  * 功能：
		从消息队列中获取消息
  * 参数：
		1、struct msg *pMsg:	消息缓冲区
  * 返回：
		成功返回零，失败返回非零值
  * 备注：
***/
int GetMsg(struct msg *pMsg)
{
	int iErr = 0;

	if(msgrcv(__g_msgid, (void*)&__g_Message, MESSAGE_NUM, TO_SERVER, 0) == -1)
	{
		iErr = -1;
	}
	else
	{
		memcpy(pMsg, __g_Message.message, sizeof(struct msg));
		printf("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ServerRecive iCmdType = %d, iParameter = %d\n", pMsg->iCmdType, pMsg->iParameter);
	}

	return iErr;
}


/***
  * 功能：
        显示升级进度
  * 参数：
        1、int iProgress	:	当前进度，0-100
  * 返回：
        成功返回零，失败返回非零值
  * 备注：
***/
static int ShowUpdateProgress(int iProgress)
{
	int iErr = 0;

	MsgSend(CMD_SHOWPROGRESS, iProgress);

	return iErr;
}

/***
  * 功能：
		获得磁盘指定分区剩余空间大小
  * 参数：
		1、const char *path:磁盘路径	
  * 返回：
		返回磁盘剩余空间大小(字节)
  * 备注：
***/
#define ROOTFS_FREESIZE_THRESHOLD   5*1024*1024             //rootfs分区空间小于5M，无法升级，需要修复软件修复
unsigned long long getDiskFreeSize(const char *path)
{
    unsigned long long freeSize = 0;
    unsigned long long blockSize = 0;
    struct statfs diskInfo;  
    if(!path)
    {
        return 0;
    }
    if(access(path, F_OK))
    {
        return 0;
    }

    statfs(path,&diskInfo);  

    blockSize = diskInfo.f_bsize;               // 每个block里面包含的字节数  
    freeSize = blockSize*diskInfo.f_bfree;

    return freeSize;
}

/***
  * 功能：
		执行解压升级功能
  * 参数：
		无
  * 返回：
		成功返回零，失败返回非零值
  * 备注：
  		关于版本信息的保存，只有升级成功，才保存版本信息
***/
static int Update(void)
{
	int iErr = 0;
	int iReturn = 0;
	int iFile;
	int iFile1;
	int iFile2;
	char cUpdateFilePath[512];
	char cCmdBuf[512];
	char cCmdBuf1[512];
	char cLogPath[512];						// 存放升级LOG信息的路径
	struct msg Msg;

	while(1)
	{
		if(GetMsg(&Msg))
		{
			continue;
		}

		switch(Msg.iCmdType)
		{
			/* 开始升级命令 */
			case CMD_UPDATE:
				/* 首次烧录，格式化所有分区 */
				#ifdef  FIRST_WRITE
				mysystem("flash_eraseall /dev/mtd0");
				mysystem("flash_eraseall /dev/mtd1");
				mysystem("flash_eraseall /dev/mtd2");
				mysystem("flash_eraseall /dev/mtd3");
				mysystem("flash_eraseall /dev/mtd4");
				mysystem("flash_eraseall /dev/mtd5");
				mysystem("flash_eraseall /dev/mtd6");
				mysystem("flash_eraseall /dev/mtd7");
				mysystem("flash_eraseall /dev/mtd8");
				mysystem("flash_eraseall /dev/mtd9");
				mysystem("flash_eraseall /dev/mtd10");
				#endif

				/* 获取真正的升级包的路径，删除升级应用程序的命令 */
				if(iErr == 0)
				{
					if(Msg.iParameter == PAR_SD)
					{
						sprintf(cUpdateFilePath, "/mnt/sdcard/firmware.tar.gz");
						sprintf(cCmdBuf, "rm -rf /mnt/sdcard/update_wndproc");
						sprintf(cLogPath, "/mnt/sdcard/log.txt");
					}
					else if(Msg.iParameter == PAR_USB)
					{
						sprintf(cUpdateFilePath, "/mnt/usb/firmware.tar.gz");
						sprintf(cCmdBuf, "rm -rf /mnt/usb/update_wndproc");
						sprintf(cLogPath, "/mnt/usb/log.txt");
					}
				}

				/* 输出信息重定向到文件当中 */
				if(iErr == 0)
				{
					int fd = 0;
					fd = open(cLogPath, O_RDWR | O_CREAT | O_TRUNC, 666);
					dup2(fd, 1);
					dup2(fd, 2);
				}

				/* 建立挂载点目录 */
				if(iErr == 0)
				{
					mysystem("mkdir -m 777 /update");
					mysystem("mkdir -m 777 /rootfs");
					mysystem("mkdir -m 777 /userfs");

					mysystem("umount /update");
					mysystem("umount /rootfs");
					mysystem("umount /userfs");
				}

				/* 挂载Rootfs分区 */
				if(iErr == 0)
				{
					sprintf(cCmdBuf1, "mount -t yaffs2 /dev/mtdblock%d /rootfs", ROOTFSMTD);
					iReturn = mysystem(cCmdBuf1);
					/* 挂载分区失败 */
					if(iReturn != 0)
					{
						MsgSend(ERR_MOUNT_ROOTFS, FAIL);
						iErr = -1;
					}
				}

				/* 挂载Userfs分区 */
				if(iErr == 0)
				{
					sprintf(cCmdBuf1, "mount -t yaffs2 /dev/mtdblock%d /userfs", USERFSMTD);
					iReturn = mysystem(cCmdBuf1);
					/* 挂载分区失败 */
					if(iReturn != 0)
					{
						MsgSend(ERR_MOUNT_USERFS, FAIL);
						iErr = -1;
					}
					
				#ifndef  FIRST_WRITE    //升级之前检测rootfs剩余空间是否足够
			        unsigned long long rootfsFreeSize = getDiskFreeSize("/");
			        printf("\n\nrootfs free size %lld\n\n", rootfsFreeSize);
			        if(ROOTFS_FREESIZE_THRESHOLD > rootfsFreeSize)
			        {
						MsgSend(ERR_MOUNT_ROOTFS, FAIL);
						iErr = -1;			        
					}
				#endif

				}

				/* 挂载Cache分区 */
				if(iErr == 0)
				{
					sprintf(cCmdBuf1, "mount -t yaffs2 /dev/mtdblock%d /update", CACHEMTD);
					iReturn = mysystem(cCmdBuf1);
					/* 挂载分区失败 */
					if(iReturn != 0)
					{
						MsgSend(ERR_MOUNT_CACHE, FAIL);
						iErr = -1;
					}
				}

				/* 解压升级包 */
				if(iErr == 0)
				{
					ShowUpdateProgress(25);

					mysystem("rm -rf /update/*");
					iReturn = CreateUpdateFile(cUpdateFilePath);
                    printf("CreateUpdateFile iReturn = %d\n", iReturn);
					/* 机器型号不匹配 */
					if(iReturn == -4)
					{
						MsgSend(ERR_SOFT_NOT_MATCH, FAIL);
						iErr = -2;
					}
					/* 解压失败 */
					else if(iReturn < 0)
					{
						MsgSend(ERR_EXTRACT, FAIL);
						iErr = -3;
					}
				}

				if(iErr == 0)
				{
					/* 显示正在写入扇区 */
					MsgSend(CMD_WRSECTOR, SUCESS);
				}

				/* 升级BootStrap.img */
				if(iErr == 0)
				{
					if ((iFile = open("/update/BootStrap.img", O_RDONLY)) != -1)
					{
						close(iFile);
						if(WriteBootStrap())
						{
							MsgSend(ERR_WRBOOTSTRAP, FAIL);
							iErr = -4;
						}
						else
						{
							strcpy(__g_CurVersion.BootStrap, __g_NewVersion.BootStrap);
						}
					}
					/* 显示进度 */
					ShowUpdateProgress(35);
				}

				/* 升级Logo.img */
				if(iErr == 0)
				{
					if ((iFile = open("/update/Logo.img", O_RDONLY)) != -1)
					{
						close(iFile);
						if(WriteLogo())
						{
							MsgSend(ERR_WRLOGO, FAIL);
							iErr = -5;
						}
						else
						{
							strcpy(__g_CurVersion.Logo, __g_NewVersion.Logo);
						}
					}
					/* 显示进度 */
					ShowUpdateProgress(40);
				}

				/* 升级Recovery.img */
				if(iErr == 0)
				{
					if ((iFile = open("/update/Recovery.img", O_RDONLY)) != -1)
					{
						close(iFile);
						if(WriteRecovery())
						{
							MsgSend(ERR_WRRECOVERY, FAIL);
							iErr = -6;
						}
						else
						{
							strcpy(__g_CurVersion.Recovery, __g_NewVersion.Recovery);
						}
					}
					/* 显示进度 */
					ShowUpdateProgress(50);
				}

				/* 升级Fpga.img */
				if(iErr == 0)
				{
				printf("--------------------------write fpga-------------------------\n");
					if ((iFile = open("/update/f216fpga_XIN_LX16.bin", O_RDONLY)) != -1)
					{
				printf("--------------------------write fpga-------------------------\n");

						close(iFile);
						if(WriteFpga())
						{
							MsgSend(ERR_WRFPGA, FAIL);
							iErr = -7;
						}
						else
						{
							strcpy(__g_CurVersion.Fpga, __g_NewVersion.Fpga);
						}
					}
					/* 显示进度 */
					ShowUpdateProgress(55);
				}

				/* 升级Kernel.img */
				if(iErr == 0)
				{
					if ((iFile = open("/update/Kernel.img", O_RDONLY)) != -1)
					{
						close(iFile);
						if(WriteKernel())
						{
							MsgSend(ERR_WRKERNEL, FAIL);
							iErr = -8;
						}
						else
						{
							strcpy(__g_CurVersion.Kernel, __g_NewVersion.Kernel);
						}
					}
					/* 显示进度 */
					ShowUpdateProgress(60);
				}

				/* 升级Rootfs.img */
				if(iErr == 0)
				{
					if ((iFile = open("/update/Rootfs.img", O_RDONLY)) != -1)
					{
						close(iFile);
						if(WriteRootfs())
						{
							MsgSend(ERR_WRROOTFS, FAIL);
							iErr = -9;
						}
						else
						{
							strcpy(__g_CurVersion.Rootfs, __g_NewVersion.Rootfs);
						}
					}
					/* 显示进度 */
					ShowUpdateProgress(80);
				}

				/* 升级Userfs.img */
				if(iErr == 0)
				{
					if((iFile = open("/update/Userfs.img", O_RDONLY)) != -1)
					{
						close(iFile);

						/* 待升级应用程序低于当前版本 */
						if(GetUserFsLowVersionFlg())
						{
							MsgSend(CMD_LOWFLG, FAIL);
							break;
						}
						else
						{
							if(WriteUserfs())
							{
								MsgSend(ERR_WRUSERFS, FAIL);
								iErr = -10;
							}
							else
							{
								strcpy(__g_CurVersion.Userfs, __g_NewVersion.Userfs);
							}
						}
					}
					/* 显示进度 */
					ShowUpdateProgress(100);
				}

				/* 只有升级成功，才保存版本信息 */
				if(iErr == 0)
				{
					#ifndef	 FIRST_WRITE
					SaveUpdateVersion(&__g_CurVersion);
					#endif
					/* 显示升级成功 */
					MsgSend(CMD_WRSUCESS, SUCESS);
                    return 0;
				}
				break;
			/* 升级Userfs.img */
			case CMD_WRUSERFS:
				if ((iFile = open("/update/Userfs.img", O_RDONLY)) != -1)
			    {
			    	close(iFile);
					if(WriteUserfs())
					{
						MsgSend(ERR_WRUSERFS, FAIL);
					}
					else
					{
						strcpy(__g_CurVersion.Userfs, __g_NewVersion.Userfs);
						SaveUpdateVersion(&__g_CurVersion);
						/* 显示升级成功 */
						MsgSend(CMD_WRSUCESS, SUCESS);
                        return 0;
					}
			    }
				break;
			/* 保存版本信息 */
			case CMD_SAVEPARAMETER:
				SaveUpdateVersion(&__g_CurVersion);
				/* 显示升级成功 */
				MsgSend(CMD_WRSUCESS, SUCESS);
                return 0;
				break;
			default :
				break;
		}
	}

	return iErr;
}


/***
  * 功能：
		主函数
  * 参数：
		1、int argc		:	参数个数
		2、char *argv[]	:	参数数组
  * 返回：
		成功返回零，失败返回非零值
  * 备注：
***/
int main(int argc, char *argv[])
{
	int iErr = 0;

	int iReturn = 0;

	if(iErr == 0)
	{
		if(InitMsgQueue())
		{
			iErr = -1;
		}
	}

	if(iErr == 0)
	{
		Update();
	}

	return iErr;
}

