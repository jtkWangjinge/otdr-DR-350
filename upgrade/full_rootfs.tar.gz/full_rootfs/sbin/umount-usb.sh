#!/bin/sh

umount -rlf /mnt/usb
Sync
rm -rf  /mnt/usb
rm -rf /tmp/usb
