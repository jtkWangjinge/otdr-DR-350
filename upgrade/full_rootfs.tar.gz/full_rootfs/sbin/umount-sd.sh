#!/bin/sh

umount -rlf /mnt/sdcard
Sync
rm -rf  /mnt/sdcard
rm -rf /tmp/sdcard
